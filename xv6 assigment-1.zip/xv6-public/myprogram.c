#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int 
main(void)
{
	printf(1, "Total number of System calls till now are %d\n", test());
	exit();
}
